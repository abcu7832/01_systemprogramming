#include "device_driver.h"

#define TIM2_TICK         	(20) 				// usec
#define TIM2_FREQ 	  		(1000000/TIM2_TICK)	// Hz
#define TIME2_PLS_OF_1ms  	(1000/TIM2_TICK)
#define TIM2_MAX	  		(0xffffu)

#define TIM4_TICK	  		(20) 				// usec
#define TIM4_FREQ 	  		(1000000/TIM4_TICK) // Hz
#define TIME4_PLS_OF_1ms  	(1000/TIM4_TICK)
#define TIM4_MAX	  		(0xffffu)

void TIM2_Stopwatch_Start(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 0);

	TIM2->CR1 = (1<<4)|(1<<3);
	TIM2->PSC = (unsigned int)(TIMXCLK/50000.0 + 0.5)-1;
	TIM2->ARR = TIM2_MAX;

	Macro_Set_Bit(TIM2->EGR,0);
	Macro_Set_Bit(TIM2->CR1, 0);
}

unsigned int TIM2_Stopwatch_Stop(void)
{
	unsigned int time;

	Macro_Clear_Bit(TIM2->CR1, 0);
	time = (TIM2_MAX - TIM2->CNT) * TIM2_TICK;
	return time;
}

/* Delay Time Max = 65536 * 20use = 1.3sec */

/* Delay Time Extended */

void TIM2_Delay(int time)
{
	int i;
	unsigned int t = TIME2_PLS_OF_1ms * time;

	Macro_Set_Bit(RCC->APB1ENR, 0);

	TIM2->PSC = (unsigned int)(TIMXCLK/(double)TIM2_FREQ + 0.5)-1;
	TIM2->CR1 = (1<<4)|(1<<3);
	TIM2->ARR = 0xffff;
	Macro_Set_Bit(TIM2->EGR,0);
	Macro_Set_Bit(TIM2->DIER, 0);

	for(i=0; i<(t/0xffffu); i++)
	{
		Macro_Set_Bit(TIM2->EGR,0);
		Macro_Clear_Bit(TIM2->SR, 0);
		Macro_Set_Bit(TIM2->CR1, 0);
		while(Macro_Check_Bit_Clear(TIM2->SR, 0));
	}

	TIM2->ARR = t % 0xffffu;
	Macro_Set_Bit(TIM2->EGR,0);
	Macro_Clear_Bit(TIM2->SR, 0);
	Macro_Set_Bit(TIM2->CR1, 0);
	while (Macro_Check_Bit_Clear(TIM2->SR, 0));

	Macro_Clear_Bit(TIM2->CR1, 0);
	Macro_Clear_Bit(TIM2->DIER, 0);
}

void TIM4_Repeat(int time)
{
	//time 1000이면 1초초
	Macro_Set_Bit(RCC->APB1ENR, 2);

	TIM4->CR1 = (1<<4)|(0<<3);
	TIM4->PSC = (unsigned int)(TIMXCLK/(double)TIM4_FREQ + 0.5)-1;
	TIM4->ARR = TIME4_PLS_OF_1ms * time - 1;

	Macro_Set_Bit(TIM4->EGR,0);
	Macro_Clear_Bit(TIM4->SR, 0);
	Macro_Set_Bit(TIM4->DIER, 0);
	Macro_Set_Bit(TIM4->CR1, 0);
}

int TIM4_Check_Timeout(void)
{
	if(Macro_Check_Bit_Set(TIM4->SR, 0))
	{
		Macro_Clear_Bit(TIM4->SR, 0);
		return 1;
	}
	else
	{
		return 0;
	}
}

void TIM4_Stop(void)
{
	Macro_Clear_Bit(TIM4->CR1, 0);
	Macro_Clear_Bit(TIM4->DIER, 0);
}

void TIM4_Change_Value(int time)
{
	TIM4->ARR = TIME4_PLS_OF_1ms * time;
}

void TIM4_Out_Init(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 2);//TIM4 ENABLE 189p
	Macro_Set_Bit(RCC->APB2ENR, 3);//GPIOB ENABLE 
	//PUSHPULL 50MHZ  open drain도 가능 PB8 LED0 144p Alternate function output(TIMER를 사용하기 때문에)
	Macro_Write_Block(GPIOB->CRH,0xf,0xe,0);
	Macro_Write_Block(TIM4->CCMR2,0xff,0x68,0);//251p

	TIM4->CCER = (0<<9)|(1<<8);//251p TIM4_CH3
}

void TIM4_Out_PWM_Generation(unsigned short freq, unsigned int duty)//freq가 1kHz
{
	// TIMXCLK = 72MHz
	// Down Counter, Repeat Mode => 241p
	Macro_Write_Block(TIM4->CR1, 0x3, 0x2, 3);
	// Timer 주파수가 TIM3_FREQ(8MHz)가 되도록 PSC 설정	
	TIM4->PSC=(unsigned int)(TIMXCLK/(double)TIM4_FREQ + 0.5) - 1; // 1kHz로 만드는 과정
	// 요청한 주파수가 되도록 ARR 설정
	TIM4->ARR=(double)(TIM4_FREQ/freq+0.5) - 1;
	// Duty Rate 
	TIM4->CCR3 = (int)(TIM4->ARR*(duty*0.1)+0.5);
	// Manual Update(UG 발생)
	Macro_Set_Bit(TIM4->EGR, 0);
	// Timer Start
	Macro_Set_Bit(TIM4->CR1, 0);
}
void TIM4_Out_Stop()
{
	Macro_Clear_Bit(TIM4->CR1,0);
}

void TIM4_Change_Value_h(unsigned int duty)
{
	TIM4->CCR3=(int)(TIM4->ARR*(duty*0.1)+0.5);
}

#define TIM3_FREQ 	  		(8000000) 	      	// Hz
#define TIM3_TICK	  		(1000000/TIM3_FREQ)	// usec
#define TIME3_PLS_OF_1ms  	(1000/TIM3_TICK)

void TIM3_Out_Init(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 1);//TIM3 ENABLE
	Macro_Set_Bit(RCC->APB2ENR, 3);//GPIOB ENABLE Alternate function output
	Macro_Write_Block(GPIOB->CRL,0xf,0xb,0);//PUSHPULL 50MHZ
	Macro_Write_Block(TIM3->CCMR2,0x7,0x6,4);
	TIM3->CCER = (0<<9)|(1<<8);
}

void TIM3_Out_Freq_Generation(unsigned short freq)
{
	// Timer 주파수가 TIM3_FREQ(8MHz)가 되도록 PSC 설정
	// TIMXCLK = 72MHz
	TIM3->PSC=(unsigned int)(TIMXCLK/TIM3_FREQ + 0.5) - 1;
	// 요청한 주파수가 되도록 ARR 설정
	TIM3->ARR=TIM3_FREQ/freq - 1;
	// Duty Rate 
	TIM3->CCR3 = (int)(TIM3->ARR)/2;
	// Manual Update(UG 발생)
	Macro_Set_Bit(TIM3->EGR, 0);
	// Down Counter, Repeat Mode, 
	Macro_Write_Block(TIM3->CR1, 0x1f, 0x14, 0);
	// Timer Start
	Macro_Set_Bit(TIM3->CR1, 0);
}

void TIM3_Out_Stop()
{
	Macro_Clear_Bit(TIM3->CR1,0);
	Macro_Clear_Bit(TIM3->DIER, 0);
}