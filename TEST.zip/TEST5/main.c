#include "device_driver.h"

static void Sys_Init(void)
{
	Clock_Init();
	LED_Init();
	Uart_Init(115200);
	Key_Poll_Init();

	SCB->VTOR = 0x08003000;
	SCB->SHCSR = 0;
}

extern volatile int Key;

void Main(void)
{
	Sys_Init();
	int cnt = 0;
	int x = 0;
	/* Set Priority: 0: Highest, 15: Lowest */
	NVIC_SetPriorityGrouping(3); 	// Binary Point = 4 (Group = 16)
	NVIC_SetPriority(30, 1); 		// TIM4
	NVIC_SetPriority(23, 2); 		// EXTI9_5
	NVIC_SetPriority(37, 3); 		// USART1

	Key_ISR_Enable(1);

	TIM4_Out_Init();
	TIM4_Repeat(1);

	for(;;)
	{
		if(TIM4_Check_Timeout())
		{
			if((Key == 0x1)&&(x == 0))//KEY1 눌린경우
			{
				Uart1_Printf("\n msec: %.1f", (double)(cnt / 100.0));
				cnt = 0;
				x = 1;
			}
			else if(Key == 0x2)//KEY0 눌린경우
			{
				cnt++;
				x = 0;
			}
		}
	}
}
