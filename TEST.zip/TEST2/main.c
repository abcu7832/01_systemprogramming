#include "device_driver.h"

static void Sys_Init(void)
{
	Clock_Init();
	LED_Init();
	Uart_Init(115200);
	Key_Poll_Init();

	SCB->VTOR = 0x08003000;
	SCB->SHCSR = 0;
}

extern volatile int Key;

void Main(void)
{
	Sys_Init();

	Macro_Write_Block(GPIOA->CRL, 0xf, 0x2, 12);//PA3
	Key_ISR_Enable(1);

	TIM4_Repeat_Interrupt_Enable(1, 1000);

	TIM4_Out_Init();
	TIM4_Out_PWM_Generation(1000, 0);//1ms정도까지만 가능함.
	

	for(;;)
	{	
	}
}
