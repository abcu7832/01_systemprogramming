#include "device_driver.h"

static void Sys_Init(void)
{
	Clock_Init();
	LED_Init();
	Uart_Init(115200);
	Key_Poll_Init();

	SCB->VTOR = 0x08003000;
	SCB->SHCSR = 0;
}

//UART 인터럽트 700line
//TIM4 인터럽트 581line

unsigned int func(unsigned int x)
{
	// 코드 구현
	Macro_Clear_Bit(x, 0);
	Macro_Write_Block(x, 0xf, 0xf, 4);
	Macro_Invert_Bit(x, 23);

	return x;
}

void Main(void)
{
	Sys_Init();
	
	/* Set Priority: 0: Highest, 15: Lowest */
	// NVIC_SetPriorityGrouping(3); 	// Binary Point = 4 (Group = 16)
	// NVIC_SetPriority(30, 1); 		// TIM4
	// NVIC_SetPriority(37, 2); 		// USART1
	// NVIC_SetPriority(23, 3); 		// EXTI9_5
	
	// Key_ISR_Enable(1);
	// Uart1_RX_Interrupt_Enable(1);

	// TIM4_Repeat_Interrupt_Enable(1, 1000);

	// TIM3_Out_Init();
	// TIM4_Out_Init();
	// TIM4_Out_PWM_Generation(1000, 0);// 1ms 정도까지만 가능함.

	Sys_Init();

	Uart_Printf("0x%.8X\n", func(0xFFFFFFFFu));
	Uart_Printf("0x%.8X\n", func(0x00000000u));
	Uart_Printf("0x%.8X\n", func(0x55555555u));
	Uart_Printf("0x%.8X\n", func(0xCCCCCCCCu));
	Uart_Printf("0x%.8X\n", func(0xAAAAAAAAu));
	Uart_Printf("0x%.8X\n", func(0x33333333u));
	//for(;;) {}
}