#include "device_driver.h"

static void Sys_Init(void)
{
	Clock_Init();
	LED_Init();
	Uart_Init(115200);
	Key_Poll_Init();

	SCB->VTOR = 0x08003000;
	SCB->SHCSR = 0;
}

extern volatile int Key;

void Main(void)
{
	Sys_Init();

	int repeat = 0;
	int init = 1;
	int x = 0;
	int cnt_Key = 0;
	/* Set Priority: 0: Highest, 15: Lowest */
	NVIC_SetPriorityGrouping(3); 	// Binary Point = 4 (Group = 16)
	NVIC_SetPriority(30, 1); 		// TIM4
	NVIC_SetPriority(23, 2); 		// EXTI9_5
	NVIC_SetPriority(37, 3); 		// USART1

	Key_ISR_Enable(1);
	Uart1_RX_Interrupt_Enable(1);

	TIM4_Out_Init();
	
	//KEY0 누르면, Key = 0
	//KEY0 안눌리면 Key = 1

	for(;;)
	{
		if((Key == 0) && (init == 1))//처음 눌린 경우우
		{
			Uart1_Printf("\nSTART\n");
			TIM4_Repeat(100);
			init = 0;
			Key = 1;
		}
		if((init == 0) && (repeat < 30))
		{
			if((Key == 0) && (x == 0)){
				Key = 1;
				cnt_Key++; 
				x = 1;
			}
			else if(Key == 1)
			{
				x = 0;
			}
			if((TIM4_Check_Timeout()) && (repeat < 30))
			{
				repeat++;
			}
		}
		if(repeat == 30)
		{
			Uart1_Printf("\nKey count %d\n", cnt_Key);
			Uart1_Printf("STOP\n");
			Macro_Clear_Bit(TIM4->CR1, 0);
			repeat = 0;
			init = 1;
			cnt_Key = 0;
		}
	}
}
