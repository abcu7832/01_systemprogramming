#include "device_driver.h"

static void Sys_Init(void)
{
	Clock_Init();
	LED_Init();
	Uart_Init(115200);
	Key_Poll_Init();

	SCB->VTOR = 0x08003000;
	SCB->SHCSR = 0;
}

extern volatile int duty;

void Main(void)
{
// 	- 코드가 실행되면 PA3에 duty 50%, 1khz 펄스가 계속 출력된다.
// - KEY0를 누르면 duty 20%로 되고 KEY1을 누르면 duty 80%로 된다.
// - 단, duty 20% 상태에서 다시 KEY0를 누르면 duty는 50%로 복귀해야한다.
// - 마찬가지로 duty 80% 상태에서 다시 KEY1을 누르면 duty 50%로 복귀해야한다.
// - 로직아날라이저에 PA3을 연결하여 파형을 확인한다.
// - (주의) 필요한 주변장치 클록은 알아서 Enable해야한다.
	Sys_Init();

	Key_ISR_Enable(1);

	TIM2_Repeat_Interrupt_Enable(1, 1000);

	TIM2_Out_Init();
	TIM2_Out_PWM_Generation(1000, 5);//1ms정도까지만 가능함.
	//TIM2_Change_Value_h(5);
	
	for(;;)
	{
		
	}
}
