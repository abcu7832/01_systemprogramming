#include "device_driver.h"

#define TIM2_TICK         	(20) 				// usec
#define TIM2_FREQ 	  		(1000000/TIM2_TICK)	// Hz
#define TIME2_PLS_OF_1ms  	(1000/TIM2_TICK)
#define TIM2_MAX	  		(0xffffu)

/*void TIM2_Out_Init(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 0);
	Macro_Set_Bit(RCC->APB2ENR, 3);
	Macro_Write_Block(GPIOB->CRL,0xf,0xb,0);
	Macro_Write_Block(TIM2->CCMR2,0x7,0x6,4);
	TIM2->CCER = (0<<9)|(1<<8);
}

void TIM2_Delay(int time)  //
{
	int i;
	unsigned int t = TIME2_PLS_OF_1ms * time;

	Macro_Set_Bit(RCC->APB1ENR, 0);

	TIM2->PSC = (unsigned int)(TIMXCLK/(double)TIM2_FREQ + 0.5)-1;
	TIM2->CR1 = (1<<4)|(1<<3);//one shot mode
	TIM2->ARR = 0xffff;
	Macro_Set_Bit(TIM2->EGR,0);
	Macro_Set_Bit(TIM2->DIER, 0);

	for(i=0; i<(t/0xffffu); i++)
	{
		Macro_Set_Bit(TIM2->EGR,0);
		Macro_Clear_Bit(TIM2->SR, 0);
		Macro_Set_Bit(TIM2->CR1, 0);
		while(Macro_Check_Bit_Clear(TIM2->SR, 0));
	}

	TIM2->ARR = t % 0xffffu;
	Macro_Set_Bit(TIM2->EGR,0);
	Macro_Clear_Bit(TIM2->SR, 0);
	Macro_Set_Bit(TIM2->CR1, 0);
	while (Macro_Check_Bit_Clear(TIM2->SR, 0));

	Macro_Clear_Bit(TIM2->CR1, 0);
	Macro_Clear_Bit(TIM2->DIER, 0);
}

void TIM2_Stopwatch_Start(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 0);

	TIM2->CR1 = (1<<4)|(1<<3);
	TIM2->PSC = (unsigned int)(TIMXCLK/50000.0 + 0.5)-1;
	TIM2->ARR = TIM2_MAX;

	Macro_Set_Bit(TIM2->EGR,0);
	Macro_Set_Bit(TIM2->CR1, 0);
}

unsigned int TIM2_Stopwatch_Stop(void)
{
	unsigned int time;

	Macro_Clear_Bit(TIM2->CR1, 0);
	time = (TIM2_MAX - TIM2->CNT) * TIM2_TICK;
	return time;
}

/////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////TIM3//////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

#define TIM3_FREQ 	  		(8000000) 	      	// Hz
#define TIM3_TICK	  		(1000000/TIM3_FREQ)	// usec
#define TIME3_PLS_OF_1ms  	(1000/TIM3_TICK)

void TIM3_Out_Init(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 1);
	Macro_Set_Bit(RCC->APB2ENR, 3);
	Macro_Write_Block(GPIOB->CRL,0xf,0xb,0);
	Macro_Write_Block(TIM3->CCMR2,0x7,0x6,4);//251p PWM1 mode
	TIM3->CCER = (0<<9)|(1<<8);
}

void TIM3_Out_Freq_Generation(unsigned short freq)
{
	TIM3->PSC = (unsigned int)(TIMXCLK/(double)TIM3_FREQ + 0.5)-1;
	TIM3->ARR = (double)TIM3_FREQ/freq-1;
	TIM3->CCR3 = TIM3->ARR/2;

	Macro_Set_Bit(TIM3->EGR,0);
	TIM3->CR1 = (1<<4)|(0<<3)|(0<<1)|(1<<0);
}

void TIM3_Out_Stop(void)
{
	Macro_Clear_Bit(TIM3->CR1, 0);
	Macro_Clear_Bit(TIM3->DIER, 0);
}

/////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////TIM4//////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
*/
// #define TIM2_TICK	  		(20) 				// usec
// #define TIM2_FREQ 	  		(1000000/TIM2_TICK) // Hz
// #define TIME2_PLS_OF_1ms  	(1000/TIM2_TICK)
// #define TIM2_MAX	  		(0xffffu)

void TIM2_Out_Init(void)
{
	Macro_Set_Bit(RCC->APB1ENR, 0);//TIM2 ENABLE 189p
	Macro_Set_Bit(RCC->APB2ENR, 2);//GPIOA ENABLE 
	//PUSHPULL 50MHZ  open drain도 가능 PB8 LED0 144p Alternate function output(TIMER를 사용하기 때문에)
	Macro_Write_Block(GPIOA->CRL,0xf,0xe,12);//PA3
	Macro_Write_Block(TIM2->CCMR2,0xff,0x68,8);//251p

	TIM2->CCER = (0<<13)|(1<<12);//251p TIM2_CH4=>BUZZER
}
/*
void TIM4_Repeat(int time)
{
	Macro_Set_Bit(RCC->APB1ENR, 2);

	TIM4->CR1 = (1<<4)|(0<<3);
	TIM4->PSC = (unsigned int)(TIMXCLK/(double)TIM4_FREQ + 0.5)-1;
	TIM4->ARR = TIME4_PLS_OF_1ms * time - 1;

	Macro_Set_Bit(TIM4->EGR,0);
	Macro_Clear_Bit(TIM4->SR, 0);
	Macro_Set_Bit(TIM4->DIER, 0);
	Macro_Set_Bit(TIM4->CR1, 0);
}*/
/*
int TIM4_Check_Timeout(void)
{
	if(Macro_Check_Bit_Set(TIM4->SR, 0))
	{
		Macro_Clear_Bit(TIM4->SR, 0);
		return 1;
	}
	else
	{
		return 0;
	}
}
*/

void TIM2_Stop(void)
{
	Macro_Clear_Bit(TIM2->CR1, 0);
	Macro_Clear_Bit(TIM2->DIER, 0);
}

// void TIM4_Change_Value(int time)
// {
// 	TIM4->ARR = TIME4_PLS_OF_1ms * time;
// }

void TIM2_Out_PWM_Generation(unsigned short freq, unsigned int duty)//freq가 1kHz
{
	// TIMXCLK 최대주파수: 72MHz
	Macro_Write_Block(TIM2->CR1, 0x3, 0x2, 3);//down repeat
	TIM2->PSC=(unsigned int)(TIMXCLK/(double)TIM2_FREQ + 0.5) - 1;//1kHz로 만드는 과정
	// = 1439
	TIM2->ARR=(double)(TIM2_FREQ/freq+0.5) - 1;//요청한 주파수가 되도록 ARR 설정
	// Duty 조정
	////////////////////////////////////////////////
	TIM2->CCR4 = (int)(TIM2->ARR*(duty*0.1)+0.5);
	////////////////////////////////////////////////
	Macro_Set_Bit(TIM2->EGR, 0);
	Macro_Set_Bit(TIM2->CR1, 0);// Timer Start
}

void TIM2_Change_Value_h(unsigned int duty)
{
	TIM2->CCR4=(int)(TIM2->ARR*(duty*0.1)+0.5);
}

void TIM2_Repeat_Interrupt_Enable(int en, int time)
{
	if(en)
	{
		Macro_Set_Bit(RCC->APB1ENR, 0);

		TIM2->CR1 = (1<<4)|(0<<3);
		TIM2->PSC = (unsigned int)(TIMXCLK/(double)TIM2_FREQ + 0.5)-1;
		TIM2->ARR = TIME2_PLS_OF_1ms * time;

		Macro_Set_Bit(TIM2->EGR,0);
		Macro_Clear_Bit(TIM2->SR, 0);
		NVIC_ClearPendingIRQ(28);
		Macro_Set_Bit(TIM2->DIER, 0);
		NVIC_EnableIRQ(28);
		Macro_Set_Bit(TIM2->CR1, 0);//TIMER START
	}

	else
	{
		NVIC_DisableIRQ(28);
		TIM2_Stop();
	}
}
